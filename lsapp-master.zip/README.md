# LaravelBlog 

Practise : simple Laravel Blog web app with authentication and file uploading.

## Version
1.0.0

## Database
The sql dump is in _db/larablog.sql